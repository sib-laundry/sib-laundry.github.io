-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 12, 2024 at 07:16 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `new_site`
--

-- --------------------------------------------------------

--
-- Table structure for table `deposit`
--

CREATE TABLE `deposit` (
  `id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `amount` float NOT NULL,
  `txn_ref` varchar(255) NOT NULL,
  `method` varchar(10) NOT NULL,
  `d_date` int(255) NOT NULL,
  `acc_name` varchar(255) NOT NULL DEFAULT '0',
  `pay_to` varchar(255) NOT NULL DEFAULT '0',
  `status` int(10) NOT NULL DEFAULT 0,
  `access_code` varchar(255) NOT NULL DEFAULT '0',
  `screenshot` varchar(255) NOT NULL DEFAULT '0',
  `real_img` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `acc_number` varchar(255) NOT NULL,
  `acc_name` varchar(255) NOT NULL,
  `bank` varchar(255) NOT NULL,
  `bank_code` varchar(255) NOT NULL DEFAULT '0',
  `status` int(10) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `invest_reward`
--

CREATE TABLE `invest_reward` (
  `id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `amount` float NOT NULL,
  `d_date` int(255) NOT NULL,
  `product_id` int(20) NOT NULL,
  `invest_reward` int(20) NOT NULL DEFAULT 1,
  `status` int(20) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE `links` (
  `id` int(255) NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `telegram` varchar(255) NOT NULL,
  `whatsapp` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `code` float NOT NULL DEFAULT 20,
  `cost` double NOT NULL,
  `com_1` double NOT NULL,
  `com_2` double NOT NULL,
  `com_3` double NOT NULL,
  `com_4` double NOT NULL,
  `com_5` double NOT NULL,
  `txn_ref` varchar(255) NOT NULL,
  `status` int(10) NOT NULL DEFAULT 0,
  `method` varchar(255) NOT NULL,
  `ref_1` int(255) NOT NULL,
  `ref_2` int(255) NOT NULL,
  `ref_3` int(255) NOT NULL,
  `ref_4` int(255) NOT NULL,
  `ref_5` int(255) NOT NULL,
  `d_date` int(255) NOT NULL,
  `verified_time` int(255) NOT NULL DEFAULT 0,
  `claim` int(25) NOT NULL DEFAULT 0,
  `ended` varchar(10) NOT NULL DEFAULT '0',
  `ref_0_claim_status` int(10) NOT NULL DEFAULT 0,
  `ref_1_claim_status` int(10) NOT NULL DEFAULT 0,
  `ref_2_claim_status` int(10) DEFAULT 0,
  `ref_3_claim_status` int(10) NOT NULL DEFAULT 0,
  `ref_4_claim_status` int(10) NOT NULL DEFAULT 0,
  `ref_5_claim_status` int(10) NOT NULL DEFAULT 0,
  `earnings_per_sec` float NOT NULL DEFAULT 0,
  `end_date` int(255) NOT NULL,
  `earnings_claimed` float NOT NULL DEFAULT 0,
  `screenshot` varchar(255) NOT NULL DEFAULT '0',
  `real_img` varchar(255) NOT NULL DEFAULT '0',
  `last_claimed` int(255) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `task_completed`
--

CREATE TABLE `task_completed` (
  `id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `amount` float NOT NULL,
  `level` int(10) NOT NULL,
  `required_count` int(200) NOT NULL,
  `d_date` int(255) NOT NULL,
  `status` int(20) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fullname` varchar(255) NOT NULL DEFAULT '0',
  `pass` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL DEFAULT '0',
  `deposit` float NOT NULL DEFAULT 0,
  `bal` float NOT NULL DEFAULT 250,
  `total_withdrawal` float NOT NULL DEFAULT 0,
  `d_date` int(255) NOT NULL,
  `status` int(25) NOT NULL DEFAULT 1,
  `ref_1` int(255) NOT NULL,
  `ref_2` int(255) NOT NULL,
  `ref_3` int(255) NOT NULL,
  `ref_4` int(255) NOT NULL,
  `ref_5` int(255) NOT NULL,
  `admin` int(10) NOT NULL DEFAULT 0,
  `last_claimed` int(255) NOT NULL DEFAULT 0,
  `p` varchar(255) NOT NULL,
  `free_funds` int(10) NOT NULL DEFAULT 0,
  `total_commision_claim` float NOT NULL DEFAULT 0,
  `last_com_claimed` int(255) NOT NULL DEFAULT 0,
  `icon` varchar(20) NOT NULL DEFAULT '1',
  `is_promoter` int(20) NOT NULL DEFAULT 0,
  `upgrade` int(255) NOT NULL DEFAULT 0,
  `tap_count` int(255) NOT NULL DEFAULT 0,
  `has_invested` int(20) NOT NULL DEFAULT 0,
  `task_claimed` int(20) NOT NULL DEFAULT 0,
  `free_claim_time` int(255) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `withdraw`
--

CREATE TABLE `withdraw` (
  `id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `amount` double NOT NULL,
  `acc_num` varchar(255) NOT NULL,
  `acc_name` varchar(255) NOT NULL,
  `bank` varchar(255) NOT NULL,
  `d_date` int(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT '0',
  `charges` float NOT NULL,
  `bank_code` varchar(255) NOT NULL,
  `txn_ref` varchar(255) NOT NULL DEFAULT '0',
  `txn_id` varchar(255) NOT NULL DEFAULT '0',
  `w_status` int(10) NOT NULL DEFAULT 0,
  `full_name` varchar(255) NOT NULL DEFAULT '0',
  `complete_message` varchar(255) NOT NULL DEFAULT '0',
  `admin_id` int(255) NOT NULL DEFAULT 0,
  `admin_phone` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `deposit`
--
ALTER TABLE `deposit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `details`
--
ALTER TABLE `details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invest_reward`
--
ALTER TABLE `invest_reward`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `links`
--
ALTER TABLE `links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `task_completed`
--
ALTER TABLE `task_completed`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdraw`
--
ALTER TABLE `withdraw`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `deposit`
--
ALTER TABLE `deposit`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `details`
--
ALTER TABLE `details`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `invest_reward`
--
ALTER TABLE `invest_reward`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `links`
--
ALTER TABLE `links`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `task_completed`
--
ALTER TABLE `task_completed`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `withdraw`
--
ALTER TABLE `withdraw`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
