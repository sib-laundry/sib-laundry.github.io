// !IS_LIVE_MODE
let popin;
let backExc;
let pageInt;
function getScreenWidth() {
    return window.innerWidth;
}
function goBack(argument) {
	if(window.history.length > 2){
		window.history.back();
	}else{
		openPage('home');
	}
}


let timer;
function startTimer(id,callBack) {
  timer = setInterval(()=>{
    timerCounter(id,callBack);
  },1000);
}
function stopTImer(callBack) {
  clearInterval(timer);
  timer = null;
}

function timerCounter(id,callBack){
  var num, days, hours, minutes, sec, cb;
    num = $(id).attr("time");
    if(num > 1){
      num = parseInt(num)-1;
      $(id).attr("time",num);
    }else{
      num = 0;
      $(id).attr("time","0");
       stopTImer();
    }
    days = Math.floor(num/86400);
    hours = Math.floor((num - (days*86400))/3600);
    minutes = Math.floor((num - (Math.floor(num/3600)*3600))/60);
    sec =  num - (Math.floor(num/60)*60);
    c_days =days+"d : "; c_hours = hours+"h : "; c_minutes =minutes+"m : ";
    if(sec < 10){ sec = "0"+sec;} if(minutes < 1){ c_minutes =""; minutes = "0"+minutes;} if(hours < 1){c_hours=""; hours = "0"+hours;} if(days < 1){c_days=""; days = "0"+days;}


    c_sec =sec+"s";
    content = c_days+""+c_hours+""+c_minutes+""+c_sec;
    $(id).html(content);

    if(num == 1){
      if(callBack !== undefined && callBack !== null){
        callBack();
      }
     
    }
}

function timerCounterUp(id,callBack, indicator){
  var num, days, hours, minutes, sec, cb;
    num = $(id).attr("time");
    if(num >= 1){
      num = parseInt(num)+1;
      $(id).attr("time",num);
    }else{
      num = 0;
      $(id).attr("time","0");
       stopTImer();
    }
    days = Math.floor(num/86400);
    hours = Math.floor((num - (days*86400))/3600);
    minutes = Math.floor((num - (Math.floor(num/3600)*3600))/60);
    sec =  num - (Math.floor(num/60)*60);
    if(indicator === true){
    	c_days =days+"d : "; c_hours = hours+"h : "; c_minutes =minutes+"m : ";
	}else{
		c_days =days+":"; c_hours = hours+":"; c_minutes =minutes+":";
	}
    if(sec < 10){ sec = "0"+sec;} 
    if(minutes < 1){ c_minutes =""; minutes = "0"+minutes;} 
    if(hours < 1){c_hours=""; hours = "0"+hours;} if(days < 1){c_days=""; days = "0"+days;}

    if(indicator === true){
    	c_sec =sec+"s";
	}else{
		if(num < 60){
			c_sec ="0:"+sec;
		}else{
			c_sec =sec;
		}
	}
    content = c_days+""+c_hours+""+c_minutes+""+c_sec;
    $(id).html(content);

    if(num == 1){
      if(callBack !== undefined && callBack !== null){
        callBack();
      }
     
    }
}

function resOpen(pageId){	
	translateHTML(pageId);
	autoCache(pageId);
	populateUser(USER);

}

function innerLoader(){
	return '<br><br><br><br><br><br><div center><span class="loader"></span></div>';
}

function openPage(param, bypass, moreParam) {
	if(typeof param ==="string"){
		var page = param;
		if(moreParam === undefined){ moreParam = ''; }
		var param ="page="+param+""+moreParam;
	}else{
		var page = param.get('page');
	}
	
	var pageVersion = localStorage.getItem('PAGE_VERSION_'+page);

	$(".main_content").show();
	var screenwidth = getScreenWidth();
	$(".nav").css("max-width",screenwidth+"px");
	if(screenwidth < 767){
		$(".mif").hide();
	}
	var id = "#"+page;
	$('.main_page').hide();
	
	var htm = $(id).html();
	$(id).show();
	if(htm ==="" || htm === innerLoader()){
		$(id).html(innerLoader());
	
		hrf = window.location.href;
		
		// cacheUrl(hrf.substring(hrf.lastIndexOf('/')),vCache);

		var urlPage = "/pages/"+page+".html?v="+pageVersion;
		// cacheUrl(urlPage,vCache);

		fetchAndLoadContent(urlPage, id,resOpen);		
	}



	if(moreParam === undefined){ moreParam = ""; }
	var url = window.location.pathname+'?page='+page+""+moreParam+'#i';
	cacheUrl(url,vCache);
	if(bypass === undefined || bypass === 'undefined'){
		setPage(page+""+moreParam+'#i','page');
	}
	scrollToElement('#pageTop');
	// loginRequired(page);
}


// Select the element you want to observe
const observedElement = document.getElementById('shareArea');

// Create a ResizeObserver instance
const resizeObserver = new ResizeObserver((entries) => {
  for (let entry of entries) {
    if(entry.contentRect.height <= 0){
    	$("#shareArea").hide();
		$(".shrBack").hide();
    }else{
    	$("#shareArea").show();
		$(".shrBack").show();
    }
  }
});

// Start observing the element
resizeObserver.observe(observedElement);

let startY;
let maxSwipeDistance = 100; // Adjust this value based on your preference
var shareArea = document.getElementById('shareArea');
shareArea.addEventListener('touchstart', touchStart);
shareArea.addEventListener('touchmove', touchMove);
shareArea.addEventListener('touchend', touchEnd);

function touchStart(e) {
startY = e.touches[0].clientY;
}

function touchMove(e) {
let currentY = e.touches[0].clientY;
let swipeDistance = currentY - startY;
var currentH = document.getElementById('shareArea').clientHeight;
var newHeight = currentH - (swipeDistance);
  document.getElementById('shareArea').style.maxHeight = `${newHeight}px`;
}

function touchEnd() {
	let currentHeight = document.getElementById('shareArea').clientHeight;
	if (currentHeight < maxSwipeDistance / 2) {
		document.getElementById('shareArea').style.maxHeight = '0';
		closeShare();
		goBack(); 
	} else {
		 document.getElementById('shareArea').style.maxHeight = '90%';
	  
	}
}


function sharePop(h,hideshrcircle){
	$("#shareContent").html(h);
	$("#shareArea").show();
	$(".shrBack").show();
	$('.shrcircle').show();
	if(hideshrcircle === true){
		$('.shrcircle').hide();
	}else{
		$('.shrcircle').show();
	}	
	window.location.href='#pop-in';
}
function showShare(htmlCallback,action, bypass,hideshrcircle){
	if(bypass === undefined){
		setPage(action,'share-pop');
	}
	
	$("#shareContent").html(htmlCallback(action));
	$("#shareArea").show();
	$(".shrBack").show();	
	document.getElementById('shareArea').style.maxHeight = '90%';
	if(hideshrcircle === true){
		$('.shrcircle').hide();
	}else{
		$('.shrcircle').show();
	}
	
}
function closeShare(back){
    // document.getElementById('shareArea').style.maxHeight = '0px';
	$(".shrBack").hide();
	$("#shareArea").hide();
	if(back === true){ goBack(); }
}

function showMenu(fl){
	$('.menu').show();
	if(fl === undefined){
		window.location.href ='#menu';
	}
}
function hideMenu(back){
	$('.menu').hide();
	if(back == undefined){ goBack(); }
}

function showShareAlt(htmlCallback,action, bypass){
	$("#shareContent_alt").html(htmlCallback(action));
	$("#shareArea_alt").show();
	$(".shrBack_alt").show();	
	document.getElementById('shareArea_alt').style.maxHeight = '90%';
	if(bypass === undefined){
		setPage(action,'share-pop-alt');
	}
}

function closeShareAlt(back){
    document.getElementById('shareArea_alt').style.maxHeight = '0px';
	$(".shrBack_alt").hide();
	$("#shareArea_alt").hide();
	if(back === true){ goBack(); }
}

function vGeneral(content) {
	closeLoader(); 
	if(parseInt(content.status) === '1'){
		popMgs(content.content,5000,true);
	}else{
		popMgs(content.content);
	}
}
function backExecute() {
	goBack();
	backExc = setTimeout(()=>{
		arguments[0](arguments[1],arguments[2],arguments[3]);
		clearTimeout(backExc); backExc = null;
	},30);

}

function bOverflowHide() {
	var screenwidth = getScreenWidth();
	if(screenwidth < 767){ $('body').css('overflow', 'hidden');}
}
function getCoData(country) {
	for (var i = 0; i < countryArr.length; i++) {
		var row = countryArr[i];
		if(country === row.country){
			return row; break;
		}
	}
}

function openServicePage(service){
	window.location.href=service+'-'+(1)+'.html?page='+service+'_home';
}

function hilightPinHole() {
	var h = $("#pinHolder").val();
	var pinhole = document.querySelectorAll('.pinhole');
	$('.pinhole').css('background', 'transparent');
	if(!isCoreEmpty(h)){
		for (var i = 0; i < h.length; i++) {
			$(pinhole[i]).css('background', '#366ff2');
		}
	}
}

function setNum(n){
	var h = $("#pinHolder").val();
	if(h.length < 6){
		$("#pinHolder").val(h+n);
		
		hilightPinHole();

		if(h.length === 5){
			var idFrm = $('[btnID-data]').attr('btnID-data');
			var callBackStr = $(idFrm).attr('callback-data');
			if(idFrm !== '#resetPinFrm'){
				$(idFrm+ ' .pin').val(h+n);
				$(idFrm).attr('onsubmit', callBackStr);
				document.querySelector(idFrm+'Btn').click();
			}else{
				if($(idFrm+ ' .pin').val() === ""){
					$(idFrm+ ' .pin').val(h+n);
					showPin(761, '#resetPinFrm');
				}else{
					$(idFrm+ ' .cpin').val(h+n);
					$(idFrm).attr('onsubmit', callBackStr);
					if($('#pinArea').attr('state') === '0'){
						document.querySelector(idFrm+'Btn').click();
					}else{
						$('#passSidePin').show();
						$('#pinSidePin').hide();
					}
					
				}	
			}
		}

	}else{
		popMgs('Too many numbers');
	}
	if(!isIOS()){
		navigator.vibrate(200);
	}
}

function clearNum() {
	var h = $("#pinHolder").val();
	if(!isCoreEmpty(h)){
		h = h.substring(0,(h.length - 1));
		$("#pinHolder").val(h);
	}
	hilightPinHole();
}

function showPin(txt,frm){
	if(frm !== '#resetPinFrm'){
		if($('#pinArea').attr('state') === '0'){
			showPin(756, '#resetPinFrm');
			return false;
		}
	}
	$("#pinHolder").val('');
	$("#pinTypin").val('');
	$('#pinTxt').html(lang[txt]);
	$('#pinArea').show();
	hilightPinHole();
	$('[btnID-data]').attr('btnID-data', frm);
	$('#passSidePin').hide();
	$('#pinSidePin').show();
	window.location.href='#pin';

}
function hidePin(){
	$('#pinArea').hide();
}

function canclePinArea(){
	$('#pinArea').hide();
	$("#pinHolder").val('');
	$("#pinTypin").val('');
	var idFrm = $('[btnID-data]').attr('btnID-data');
	if(idFrm !== ""){
		$(idFrm+' .pin').val('');
		$(idFrm+' .cpin').val('');
	}
	$('#resetPinFrm .pass').val('');
	hidePin();
	resetPinArea();
}
function resetPinArea(){
	$('#resetPinFrm').attr("onsubmit", "showPin(757, '#resetPinFrm'); return false;");	
	$('#resetPinFrm .pin').val('');
	$('#resetPinFrm .cpin').val('');
	$('#pinHolder').val('');
	var frm = $('[btnID-data]').attr('btnID-data');
	$(frm+' .pin').val('');
	clearNum();
}
function vPin(content,eClass) {
	closeLoader();
	hidePin();
	resetPinArea();
	if(parseInt(content.status) === 1){
		$('#pinArea').attr('state', '1');
		popMgs(content.content,10000,true);
		// updateUser('uid', 'users', localStorage.getItem('USER_ID'), content.USER);
	}else{
		popMgs(content.content);
	}
}

function vOrder(content) {
	closeLoader();
	hidePin();
	resetPinArea();
	if(parseInt(content.status) === 1){
		popMgs(content.content,10000,true);
		// updateUser('uid', 'users', localStorage.getItem('USER_ID'), content.USER);
	}else{
		popMgs(content.content);
	}
}

function vDeposit(content) {
	closeLoader();
	if(parseInt(content.status) === 1){
		popMgs(content.content,10000,true);
		addUser('deposit', content.transactions);
		window.location.href = content.link;
	}else{
		popMgs(content.content);
	}
}


function isLogin(){ 
  if(isCoreEmpty(localUser.get('login'))){
    return false;
  }else{
    return true;
  }
}
function emptyPage(id){
	if(id === undefined) { id = '.main_page'; }
	$(id).html('');
}

function switchAccNow(uid){
	loader();
	jsGetRowData('uid', 'users', uid, (rows)=>{
		if(rows.length > 0){
			emptyPage();
			USER= rows;
			localUser.set({uid: uid, login: true});

			populateUser(USER);
			closeLoader();
			closeShareAlt(true);
			if(!isCoreEmpty(pageInt)){ clearTimeout(pageInt); pageInt = null; }
			pageInt = setTimeout(()=>{
				openPage('user_home');
				updataUserBackend(USER[0].login_data);
				clearTimeout(pageInt); pageInt = null;
			},100);
		}else{
			popMgs('Unable to login to this account'); closeLoader();
		}
	});
}

function switchAcc(){
	// return 'Ues';
	// console.log('ddddddddddddddd');

	jsGetMultiData('users', (rows)=>{
		h = '';
		if(rows.length > 0){
			for (var i = 0; i < rows.length; i++) {
				data = rows[i];
				if(parseInt(data.login_is_valid) === 1) {
					if(data.uid === localUser.get('uid')){
						opc ='opacity:0.4';
						ico ='<span class="ang" style="background: #009206; color: #fff;"><i class="fa-solid fa-check"></i></span>';
						onclk ='closeShareAlt(true);'; 
					}else{
						opc ='';
						ico ='<span class="ang" style="background: #f6f6f6;"><i class="fa-solid fa-angle-down"></i></span>';
						onclk ="switchAccNow('"+data.uid+"');";
					}

					h = `${h} <div class="blm" onclick="${onclk}">
				        <div flo style="width:50px; ${opc}">
				            <img src="${data.icon}" class="profi">
				        </div>
				        <div flo w_70 style="${opc}"">
				            <h4 style="padding-top: 4px; padding-bottom: 5px;"><span>${data.firstname+' '+data.surname}</span></h4>
									<p fz_10 style="color: grey; font-size: 10px">${data.phone}</p>
				        </div>
				        <div flo style="width: calc(30% - 50px);" right>
				            ${ico}
				        </div>
				        <div cl></div>
				    </div>`;

				}
			}
		}

		h = `${h} <div cl>
        <br>
        <div h_zero>
            <div class="blm_b" onclick="backExecute(openPage, 'register')"></div>
        </div>
        <div h_zero class="logout">
            <div class="blm_b" onclick="backExecute(logout)" style="margin-left: 50%;"></div>
        </div>
        <div class="blm">

            <div h_zero right class="logout"><p class="lgo">Logout</p></div>
            <p style="color: #868686;">Creat new account</p>

        </div>
    </div>`

		$('#shareContent_alt').html(h);
	})
	
}


function logout(){
	showShareAlt(logoutNow,'logoutNow');
}

function logoutNow(){
	h = `<h2 center>Do you want to logout?</h2> <div cl>
      <br>
      <div flo w_50>
          <button class="btn" onclick="closeShareAlt(true);" w_90="" style="background: #000;">No</button>
      </div>
			<div flo w_50 right >
          <button class="btn" onclick="localUser.set({uid: undefined, login: undefined}); emptyPage(); openPage('login');  " w_90="">Yes</button>
      </div>
      <br cl><br>`;

		$('#shareContent_alt').html(h);
}

function hideLogout() {
	if(!isCoreEmpty(pageInt)){ clearTimeout(pageInt); pageInt = null; }
	pageInt = setTimeout(()=>{
		$('.logout').hide();
		$('.blm_b').css('width', '100%');
		clearTimeout(pageInt); pageInt = null;
	}, 100);
}







function vSignUp(content) {
	
	if(parseInt(content.status) === 1){
		
		popMgs(content.content,3000,true);
		if(parseInt(content.type) === 0){
			closeLoader();
			openPage('confirm_otp', undefined,content.link);
		}else{
			if(!isCoreEmpty(pageInt)){ clearTimeout(pageInt); pageInt = null; }
			
			USER = content.USER;

	    localUser.set({uid: USER.uid, login: true});

			jsGetRowData('uid', 'users', USER.uid, (rows)=>{
				if(rows.length > 0){
					updateUser('uid', 'users', USER.uid, USER);
				}else{
					addUser('users', USER);
				}
			});			

			

	    if(isCoreEmpty(localUser.get('page_index'))){
				localUser.set({page_index: getRndInteger(1, 5)});
			}
	    pageInt = setTimeout(()=>{	    	
					window.location.href='index-'+(localUser.get('page_index'))+'.html?page=user_home';
					clearTimeout(pageInt); pageInt = null;    	
	    }, 100);
	    
		}
		
	}else{
		closeLoader();
		popMgs(content.content);
	}
}

function pickOrderMethod(option) {
	var customerPhone = $('#customerPhone').val();
	var deliverMethod = $('#deliverMethod').val();
	if(isCoreEmpty(customerPhone)){
		errorMark('#customerPhone');
		popMgs("Please enter customer's phone number");
		return false;
	}
	if(isCoreEmpty(deliverMethod)){
		errorMark('#deliverMethod');
		popMgs("Please choose delivery method");
		return false;
	}
	if(option === 1){
		document.querySelector('#releaseTradeFrmBtn').click();
	}
}

function errorMark(id){
	$(id).attr('errorMark', 'true');

	// errMark = setTimeout(()=>{
	// 	$(id).removeAttr('errorMark');
	// }, 10000);
}




function inputLen(inp,len) {
	var txt = $(inp).val();
	if(txt.length > len){ txt = txt.substring(0,len); }
	$(inp).val(txt); 
}

function loginRequired(){
if(!isCoreEmpty(pageInt)){ clearTimeout(pageInt); pageInt = null; }

pageInt = setTimeout(()=>{
	var url = getCurUrl();;
	var param =url[2];
	page ='';
	if(param.has('page')){ page = param.get('page'); }
	console.log('page', page);
	

	// if(!isCoreEmpty(page)){
	// 	if(!isLogin() && ($.inArray(page,["0","login", "home","register", "confirm_otp", "faq"])) < 1){
	// 		openPage('login'); return false;
	// 	}
	// }
	clearTimeout(pageInt); pageInt = null;
},100);
}
function generalAction(hashState, param) {
	// if(hashState !== 'chatme'){
	// 	$('.chatme').hide();
	// 	$('body').css('overflow', 'auto');
	// }else{
	// 	bOverflowHide();
	// 	$('.chatme').show();
	// }

	// if(param.has('shpop')){
	// 	showShPop(false);
	// }else{
	// 	hideShPop();
	// }
	var page ='';
	if(param.has('page')){
		page = param.get('page');
	}
	
	
	


	if(param.has('share-pop')){
		var sharPage = param.get('share-pop');
		// showShare(htmlCallbackHolder(sharPage),param, false);
	}else if(param.has('share-pop-alt')){
		var sharPageAlt = param.get('share-pop-alt');
		// showShareAlt(htmlCallbackHolder(sharPageAlt),param, false);
	
	}else if(hashState === 'pop-in'){
		if($("#shareContent").html() !== ''){
			$("#shareArea").show();
			$(".shrBack").show();
			document.getElementById('shareArea').style.maxHeight = '90%';
		}
	}else if(param.has('pop-alt')){
		$("#shareArea_alt").show();
		$(".shrBack_alt").show();
	
	}else if(hashState === 'menu'){
		showMenu(false);

	}else{
		closeShare();
		closeShareAlt();
		hideMenu(false);
	}
	populateUser(USER);
	if(hashState !== 'pin'){
		hidePin();
		resetPinArea();
	}
	
	ref = localUser.get('ref');
	if(param.has('ref')){
		var ref = param.get('ref');		
	}
	if(!isCoreEmpty(ref)){
		$('#refID1').val(ref);
		localUser.set({ref: ref});	
	}

	// setNavInfo(param);
	
	hideBottom(page);
  setBottomPst(page);

  if(page === 'confirm_otp'){
  	var email = param.get('e');
  	var auth = param.get('auth');
  	
  	if(param.has('otp')){
  		$('#optInp').val(param.get('otp'));
  	}
  	if(param.has('d_action')){
  		d_action = param.get('d_action');
  	}else{
  		d_action = 'confirm_otp';
  	}
  	$('#otpActionInp').val(d_action);
  	$('#otpAuthInp').val(auth);
  	$('.emailT').html(email);
  }


}


function pushAjaxRequest(action,urlPOST,loadCallback,callBack,param,param2){
	if(loadCallback !== undefined){
		loadCallback(param2);
	}
	$.ajax({
		type: "POST",
		url : parseLoadUrl(urlPrefix()+urlPOST),
		data: "action="+action,
		success: function(result){
			// if(action.indexOf('fetch_airtime_records') >= 0){
				console.log('Result '+action,':',result);
			// }


			result1 = result;
			result = result.substring(result.indexOf("{"));
			result = result.substring(0,result.lastIndexOf("}")+1);
			if(result.indexOf('{') ==0 && isValidJSON(result)){
				var content = JSON.parse(result);
				if(content?.payload){
					if((content.payload).length > 0){
						pushNotification(JSON.stringify(content.payload), JSON.stringify(content.pushSubscription), content.d_time, content.hash);
					}
				}

				if(callBack !== undefined){
					callBack(content,param);
					console.log("content", ":", param);
				}
			}else{
				closeLoader();
			}
		}
	});
}






function ajaxFormSub(e,id,d,urlPost,callBack,loadCallback,param) {
	if(loadCallback !== undefined){
		loadCallback(param);
	}
	e.preventDefault();    
	var formData = new FormData(d);
	$.ajax({
		url: parseLoadUrl(urlPrefix()+urlPost),
		type: 'POST',
		data: formData,
		success: function (result) {
			console.log(result);
			result = result.substring(result.indexOf("{"));
			result = result.substring(0,result.lastIndexOf("}")+1);
			if(result.indexOf('{') ==0 && isValidJSON(result)){
				var content = JSON.parse(result);
				if(content?.payload){
					if((content.payload).length > 0){
						pushNotification(JSON.stringify(content.payload), JSON.stringify(content.pushSubscription), content.d_time, content.hash);
					}
				}
				if(callBack !== undefined){
				 callBack(content,param);	    
				}
			}else{
				closeLoader();
				popMgs(lang[133]);			
			}
		},
		cache: false,
		contentType: false,
		processData: false
	});
}


function loader(back){
	$(".loadA").show();
	$(".loadB").show();
}

function closeLoader(back){
	$(".loadA").hide();
	$(".loadB").hide();
}


function popMgs(h, dur, success) {
	$(".poph").html(h);
	$(".pin").show();
	closePop(dur);
}

function closePop(dur){
	if(dur ===  undefined || dur === "undefined"){ dur = 4500;}
	if(popin !== undefined){
		clearTimeout(popin);
	}
	popin = setTimeout(()=> {
		$(".pin").hide();
		clearTimeout(popin);
	},dur);
}
function setBottomPst(page) {
	if(!isCoreEmpty(page)){
		$('.bttm_page [flo]').attr('id', "");
		$('.lud_ic').attr('id', "");
		$('.'+page).attr('id', "activ_bttm");
		hideBottom(page);
	}	
}

function hideBottom(page){
	var noChat = ["login", "home","register", "confirm_otp", "transactions", "faq", "deposit_records", "payout_records", "link_bank", "notifications", "profle"];
	var a = $.inArray(page,noChat);
	if (a >= 0) {
		if(($.inArray(page, ["login", "home","register"])) >= 0){
			$('.lu_nav').hide();
		}else{
			$('.lu_nav').show();
		}
		$('.bttm_page').hide();
		$('.chatb').css('bottom', '15px');
	}else{
		$('.lu_nav').show();
		$('.bttm_page').show();
		$('.chatb').css('bottom', '65px');
	}


}



function scrollToElement(id,add,remove) {
	if(remove === undefined){ remove =0; } if(add === undefined){ add = 0; }
  const el = document.querySelector(id);
  if (el) {
    const topPos = el.getBoundingClientRect().top + (window.scrollY - remove) + add; 
    // element position relative to page, minus 100px offset
    window.scrollTo({
      top: topPos,
      behavior: 'smooth' // smooth scrolling
    });
  }
}




window.onscroll = function(){
	var url = getCurUrl();
	var hashState =url[1];
	var param =url[2];

	if(param.has('page')){
		var page = param.get('page');

		var moreRec = ["app_notification","p2p_trade"];
		var a = $.inArray(page,moreRec);
		if (a >= 0) {

		}
	}


}




window.addEventListener('hashchange', function(){
	var url = getCurUrl();
	var hashState =url[1];
	var param =url[2];
	generalAction(hashState, param);

	
	if(param.has('more') && param.has('p')){
		mPage = param.get('p');
		showMoreMenu(htmlCallbackHolder(mPage),'#'+mPage,true);
	}
	


	

});

window.addEventListener("popstate", () =>{
	var url = getCurUrl();
	var hashState =url[1];
	var param =url[2];
	generalAction(hashState, param); 

	if(param.has('more') && param.has('p')){
		mPage = param.get('p');
		showMoreMenu(htmlCallbackHolder(mPage),'#'+mPage,true);
	}
	
	if(param.has('page')){
		if(isCoreEmpty(backExc)){
			openPage(param, false);
		}
	}

});


function setPage(page,firstParam){
	firstParam = firstParam ? firstParam: 'open';
	var paramiter = new URLSearchParams(window.location.search);
	paramiter.set("fetch",page);
	var addRef = "";

	history.pushState(page, page+" Page","?"+addRef+firstParam+"="+page);
	
	var url = getCurUrl();
	var hashState =url[1];
	var param = url[2];
	
	generalAction(hashState, param); 
}	



window.onresize = function() {
    // $(".mif").show();
    // var url = getCurUrl();
	// var hashState =url[1];
	// var param =url[2];
    // if(param.has('page')){
	// 	openPage(param, false)
	// }
	// var screenwidth = getScreenWidth();
	// if(screenwidth >= 767){ 
	// 	$('body').css('overflow', 'auto');
	// }else{
	// 	if(hashState === 'menu'){ bOverflowHide(); }
	// }
};


function onloadCall(bypass) {
	var url = getCurUrl();
	var hashState =url[1];
	var param =url[2];

	generalAction(hashState, param);

	if(param.has('more') && param.has('p')){
		mPage = param.get('p');
		showMoreMenu(htmlCallbackHolder(mPage),'#'+mPage,true);
	}else{
		
	}
	var page ='';
	if(param.has('page')){
		var page = param.get('page');
		$('#'+page+'_page').html('');
		openPage(param, false)
	}else{
		page = 'home';
		openPage('home');
	}
	hideBottom(page);

	ref = localUser.get('ref')
	if(param.has('ref')){
		var ref = param.get('ref');		
	}
	if(!isCoreEmpty(ref)){
		$('#refID1').val(ref);
		localUser.set({ref: ref});
		
	}


	

	if(bypass === undefined) {
		var pageVersion1 = localStorage.getItem('VERSION_bottomHolder');
		var urlC = "/components/bottom.html?v="+pageVersion1;
		fetchAndLoadContent(urlC, "#bottomHolder",(pageId)=>{
			autoCache(pageId);
			translateHTML(pageId);
			setBottomPst(page);
		});
		cacheUrl(urlC);		
	}

	

}
function updataUserBackend(login_data) {
	pushAjaxRequest('check_login_state&login_data='+encodeURIComponent(login_data),'php/handle_login.php',undefined,(content)=>{
		if(content?.login_is_valid){
			localUser.set({uid: undefined, login: false});

			updateUser('uid', 'users', localUser.get('uid'), {login_is_valid: 0});
			openPage('login');
		}else{
			if(parseInt(content.status) === 1){
				USER = [content.USER];
				populateUser(USER);
				updateUser('uid', 'users', localUser.get('uid'), USER[0]);
			}
		}

		jsGetMultiData('system_settings', (rows)=>{
			if(rows.length >  0){
				updateUser('tid', 'system_settings', 1, {min_deposit: content.min_deposit});
			}else{
				addUser('system_settings', {tid: 1, min_deposit: content.min_deposit});
			}

		});

  });
}

onload=function(){
	if(isCoreEmpty(localUser.get('page_index'))){
		localStorage.setItem('PAGE_INDEX', getRndInteger(1, 5));
		localUser.set({page_index: getRndInteger(1, 5)});
	}
	
	
	onloadCall();

	if(isLogin()){
		if(!isCoreEmpty(pageInt1)){ clearTimeout(pageInt1); pageInt1 = null; }

		pageInt1 = setTimeout(()=>{
			if(isCoreEmpty(USER)){
				jsGetRowData('uid', 'users', localUser.get('uid'), (rows)=>{
					if(rows.length >  0){
						USER = rows;
						populateUser(USER);					
						updataUserBackend(USER[0].login_data);
					}

				});
			}else{
				updataUserBackend(USER[0].login_data);
			}
			
			clearTimeout(pageInt1); pageInt1 = null;
		}, 40);
	}

	// let newUrlsToCacheArr = ["/index.html",	"/offline.html"];
	// var d_script= document.querySelectorAll('[src]');
	// if(d_script.length > 0){
	// 	for (var i = 0; i < d_script.length; i++) {
	// 		txt_src = $(d_script[i]).attr('src');
	// 		if(txt_src.substring(0, 1) === "/" && txt_src !== '/assets/js/uncache.js' && txt_src !== '/socket.io/socket.io.js'){
	// 			newUrlsToCacheArr.push(txt_src);
	// 		}
			
	// 	}
	// }
	// var d_script= document.querySelectorAll('[href]');
	// if(d_script.length > 0){
	// 	for (var i = 0; i < d_script.length; i++) {
	// 		txt_src = $(d_script[i]).attr('href');
	// 		if(txt_src.substring(0, 1) === "/"){
	// 			newUrlsToCacheArr.push(txt_src);
	// 		}
	// 	}
	// }

	// bulkCache(newUrlsToCacheArr);
}

