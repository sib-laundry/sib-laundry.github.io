// function systemDefaultTheme(){
// 	var themeColor;
// 	var prefersDarkScheme = window.matchMedia("(prefers-color-scheme: dark)");
// 	if (prefersDarkScheme.matches) {
// 		themeColor ='dark';
// 	} else {
// 	  themeColor ='light';
// 	}
// 	return themeColor;
// }
// function getTheme(){
// 	var mode = localStorage.getItem('themeMode');
// 	var theme = mode ? mode :'systemDefault';
// 	return theme;
// }

// var themeColor;
// var theme = getTheme();
// if(theme === 'systemDefault'){
// 	themeColor = systemDefaultTheme();
// }else{
// 	themeColor = theme;
// }
// const isDarkScheme = window.matchMedia("(prefers-color-scheme: dark)");
// isDarkScheme.addEventListener('change', (e) => {
// 	if(getTheme() === 'systemDefault'){
// 	  if (e.matches) {
// 	  	themeColor ='dark';
// 	  } else {
// 	  	themeColor ='light';
// 	  }
// 	  execTheme(themeColor);
// 	}
// });

// function execTheme(theme){
// 	document.querySelector("#themeMode").setAttribute("href","/assets/css/"+theme+".css?version=1");
// }
// execTheme(themeColor);

// function setTheme(theme){
// 	if(theme === 'systemDefault'){
// 		themeColor = systemDefaultTheme();
// 	}else{
// 		themeColor = theme;
// 	}
// 	localStorage.setItem('themeMode', theme);
// 	execTheme(themeColor);
// 	var tdv = document.querySelectorAll('.theme_tag_div');
// 	for (var i = 0; i < tdv.length; i++) {
// 		tdv[i].innerHTML ='';
// 	}
// 	document.querySelector("#"+theme+"Theme").innerHTML = '<div class="theme_tag"><i class="fa-solid fa-check"></i></div>';
// }