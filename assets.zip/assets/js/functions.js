class SelectRollback {
  constructor(selector, onChangeCallback = null) {
    this.select = document.querySelector(selector);
    if (!this.select) return; // Exit if element not found

    this.previousValue = this.select.value;
    this.onChangeCallback = onChangeCallback; // Store callback function

    // Store previous value on focus
    this.select.addEventListener('focus', () => {
      this.previousValue = this.select.value;
    });

    // Handle value change
    this.select.addEventListener('change', () => {
      const oldStatus = this.returnStatus(this.previousValue);
      const newStatus = this.returnStatus(this.select.value);
      let currentValue;

      if (!confirm(`Change action from "${oldStatus}" to "${newStatus}"?`)) {
        this.select.value = this.previousValue; // rollback
        currentValue = this.previousValue;
      } else {
        this.previousValue = this.select.value; 
        currentValue = this.select.value;
      }
      if (typeof this.onChangeCallback === 'function') {
        this.onChangeCallback({
          element: this.select,
          oldValue: this.previousValue,
          newValue: this.select.value,
          oldStatus,
          newStatus,
          currentValue
        });
      }
      
    });
  }

  // Convert number/string to readable status
  returnStatus(value) {
    const statuses = ["Pending", "Approve", "Declined"];
    const num = this.isCoreEmpty(value) ? 0 : parseInt(value);
    return statuses[num] || statuses[0];
  }

  // Check for empty/invalid values
  isCoreEmpty(val) {
    return val === null || val === undefined || val === "" || isNaN(val);
  }
}


function siteName(){
  return "D2Point";
}

function isIOS() {
  return /iPhone|iPad|iPod/i.test(navigator.userAgent) ||
         (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
}

function pasteTxt(inp) {

    if (navigator.clipboard) {
        async function checkClipboardPermission() {
          try {
            const permissionStatus = await navigator.permissions.query({ name: 'clipboard-read' });

            if (permissionStatus.state === 'granted' || permissionStatus.state === 'prompt') {
              pasteFromClipboard();
            } else if (permissionStatus.state === 'denied') {
                if(lang[268] !== undefined){
                    popMgs(lang[268],10000);
                }
            }

            // Listen for changes to the permission state
            permissionStatus.onchange = function() {
              if (this.state === 'granted') {
                pasteFromClipboard();
              } else if (this.state === 'denied') {
                if(lang[268] !== undefined){
                    popMgs(lang[268],10000);
                }
              }
            };
          } catch (err) {
            console.error('Permission API or Clipboard API not supported', err);
          }
        }



      async function pasteFromClipboard() {
        try {
          const text = await navigator.clipboard.readText();
          document.querySelector(inp).value = text;
        } catch (err) {
          console.error('Failed to read clipboard contents:', err);
        }
      }
      checkClipboardPermission();
    } else {
      console.error('Clipboard API not available');
    }
}

function lastSeenTime(timeStamp, d_time,langIndex) {
  const timeDiff = timeStamp - d_time;
  let word;

  if (timeDiff <= 86400) {
    word = "today";
  } else if (timeDiff <= 172800) {
    word = "yesterday";
  } else {
    const day = new Date().getDay(); // Convert to milliseconds
    
    const difDay = (day + 1) * (86400);
    // alert(timeDiff+' == '+difDay);

    if (timeDiff <= 518400 && difDay < 518400) {
      const arr = ["Sunday", "Monday", "Tuesday", "Wenesday", "Thursday", "Friday", "Saturday"];
      word = arr[day];
    } else {
      const dateObj = new Date(d_time * 1000); // Convert to milliseconds
      const month = dateObj.getMonth(); // 0-based month
      const dayOfMonth = dateObj.getDate();
      const year = dateObj.getFullYear();
      const arr = [
        "January", "Febuary", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
      ];
      word = `${arr[month]} ${dayOfMonth}, ${year}`;
    }
  }

  const ampm = { "PM": "PM", "AM": "AM" };
  const dateObj = new Date(d_time * 1000); // Convert to milliseconds
  const hours = dateObj.getHours();
  const minutes = dateObj.getMinutes();
  const period = hours >= 12 ? "PM" : "AM";
  const formattedHours = hours % 12 || 12; // convert 24-hour time to 12-hour time, adjusting 0 to 12
  const formattedMinutes = minutes < 10 ? "0" + minutes : minutes;
  if(langIndex === undefined){
        langIndex ="Date: #";
    }else{
        langIndex = langTxt(langIndex);
    }
  
  const txt = langIndex.replace("#", word) + " " + formattedHours + ":" + formattedMinutes + " " + ampm[period];
  return txt;
}



function htmlCallbackHolder(mPage){

    let menuFuncObj ={
        engagement: engagement,
        buy_account: buy_account,
        delAccount: delAccount,
        createDepositWallet: createDepositWallet,
        creatReserveAccount: creatReserveAccount,
        takeALook: takeALook,
        p2pOrder: p2pOrder,
        buyAccPop: buyAccPop,
        prinCard: prinCard,
        getVerified: getVerified,
        cancleTrade: cancleTrade,
        callDispute: callDispute,
        moreBulkSMS: moreBulkSMS,
        releaseTrade: releaseTrade,
        needLogin: needLogin,
        depTrans: depTrans,
        upgradePop: upgradePop,
        askPushNotification: askPushNotification,
        cableTrans: cableTrans,
        dataTrans: dataTrans,
        airtimeTrans: airtimeTrans,
        callLogout: callLogout,
        proceedTrade: proceedTrade
    }
    return menuFuncObj[mPage];
}


function bluSty(id) {
    const blured = document.querySelectorAll(id);
    blured.forEach(div =>{
        const img = div.querySelector("img");
        function loaded() {
            div.classList.add("loaded");
        }
        if(img.complete){
            loaded();
        }else{
            img.addEventListener("load", loaded);
        }
    });
}
function numberSuffix(number) {
    number = parseInt(number);
    const ends = ['th', 'st', 'nd', 'rd', 'th', 'th', 'th', 'th', 'th', 'th'];
    let abbreviation;
    
    if (number % 100 >= 11 && number % 100 <= 13) {
        abbreviation = number + 'th';
    } else {
        abbreviation = number + ends[number % 10];
    }
    
    return abbreviation;
}

function genToggle(hide_class, id,btn,class_add,btnId) {
    var bAll,bAllLen;
    cdiv = document.querySelectorAll(hide_class);
    cdivLen = cdiv.length;
    if(cdivLen > 0){
        for (var i = 0; i < cdivLen; i++) {
            cdiv[i].style.display ='none';
        }
    }
    document.querySelector(id).style.display ='block';
    if(btn !== undefined){
        bAll = document.querySelectorAll(btn);
        bAllLen = bAll.length;
        if(bAllLen > 0 ){
            for (var i = 0; i < bAllLen; i++) {             
                bAll[i].classList.remove(class_add);
            }
        }
        document.querySelector(btnId).classList.add(class_add);
    }
}

function setNavInfo(param) {
    var url = getCurUrl();
    var param =url[2];
    
    $(".topnav").hide();
    if(lang !== undefined && lang !== "undefined"  && lang !== null){
        let pageLanText ={
            deposit: langTxt(39),
            wallet: langTxt(89),
            invite: langTxt(90),
            deposit_record: langTxt(35),
            downline: langTxt(126),
            income_records: langTxt(127),
            all_time_payout: langTxt(128),
            bank: langTxt(130),
            verify_email: langTxt(136),
            verify_phone: langTxt(137),
            sell: langTxt(207),
            buy_account: langTxt(208),
            pay_bills: langTxt(57),
            buy_airtime: langTxt(65),
            buy_data: langTxt(64),
            get_website: langTxt(60),
            telegram_tv: langTxt(62),
            whatsapp_tv: langTxt(61),
            print_card: langTxt(58),
            print_record: langTxt(261),
            p2p: langTxt(200),
            p2p_set_price: langTxt(271),
            p2p_buy: langTxt(72),
            p2p_orders: langTxt(71),
            chat: langTxt(283),
            engagement: langTxt(295),
            boost: langTxt(295),
            recharge_2cash: langTxt(66),
            contact_us: langTxt(59),
            profile: langTxt(395),
            printing: langTxt(556),
            mining: langTxt(568),
            support: langTxt(602),
            get_verified: langTxt(290),
            sell_record: langTxt(658),
            bulk_sms: langTxt(672),
            bulk_sms_record: langTxt(688),
            p2p_orders: langTxt(214),
            p2p_trade: langTxt(714),
            p2p_ads_buy: langTxt(715),
            p2p_ads_sell: langTxt(715),
            pay: langTxt(731),
            buy_account_order: langTxt(214),
            text_to_speech: langTxt(808),
            transaction: langTxt(853),
            transfer: langTxt(854),
            app_notification: langTxt(886),
            pay_bill_record:  langTxt(912),
            airtime_record:  langTxt(914),
            buy_data_record:  langTxt(913),
            offline_data_beneficiary:  langTxt(931),

        }
        if(param.has('p')){
            var txt = pageLanText[param.get('p')];
        }else{
            var txt = pageLanText[param.get('page')];
        }
        if(param.get('page') === "home" || txt === undefined){
            if(lang !== undefined){
                $("title").html(langTxt(88));
            }
        }else{
            $('.backH').html(txt);              
            $("#pageTop").show();
            $("title").html(txt);
        }
    }
}

// Wrapping the jQuery load function inside a promise
function loadContent(url, elementSelector) {
  return new Promise((resolve, reject) => {
    // parseLoadUrl(url)
    $(elementSelector).load(url, (response, status, xhr) => {
      if (status === "success") {
        resolve(response);
      } else {
        reject(new Error(`Failed to load content..: ${xhr.status} ${xhr.statusText}`));
      }
    });
  });
}


// Using the async function with await
async function fetchAndLoadContent(link, id, callBack,param) {
  try {
    await loadContent(siteBaseUrl()+link, id);
    if(callBack !== undefined){
        callBack(id);
    }

  } catch (error) {
    console.error(error.message);
  }
}

function startSlide(id,speed){
    var splide = new Splide( id, {
      direction: 'ttb',
      height   : '10rem',
      type   : 'loop',
      autoScroll: {
            speed: speed,
            rewind: true,
        }
    } );

    splide.mount(window.splide.Extensions);

    //     new Splide( id,{
    //     type   : 'loop',
    //     drag   : 'free',
    //     focus  : 'up',
    //     autoScroll: {
    //         speed: speed,
    //         rewind: true,
    //     },
    // } ).mount(window.splide.Extensions );
}


function handleFiles(event,preventD) {
    $('#dropZone').hide();
    if(preventD === true){
        event.preventDefault(); // Prevent default behavior (prevents file from being opened)
        var files = event.dataTransfer.files;
        inputFile = document.getElementById('p2pdoc');
        inputFile.files = files;

    }else{
        var files = document.getElementById('p2pdoc').files ;
    }
    
    // Get the dropped files
    $('#docHolder').html(""); 
    let len = files.length;
    if(len > 4){
        popMgs(langTxt(615)); 
        // return false;
    }
    for (let i = 0; i < files.length; i++) {
        
        file = files[i];

        let cfilename = file.name;
        let ctype= cfilename.substring(cfilename.lastIndexOf('.')+1);
        let chatFileType = ctype.toLowerCase();

        var addClass =""; var addHtml ="";

        if(i < 4){
            if(len > 1){
                if(i == 1){
                    addClass =" chatdoc_active";
                    setSizeInfo(file.lastModified,file.size);
                    
                }
                del ='<div h_zero><span class="cpurge" onclick="removeImg(\'#dvimg'+i+'\',\''+(i + 1)+'\'); return false;"><i fz_18 class="fa-solid fa-trash-can"></i></span></div>';
            }else{
                del = '';
                if(i == 0){
                    addClass =" chatdoc_active";
                    setSizeInfo(file.lastModified,file.size);
                }
            }
            if(cfilename.length > 6){
                cnameAdd= cfilename.substring(0,3)+"..."+cfilename.substring(cfilename.length-7);
            }else{
                cnameAdd= cfilename;
            }
            addHtml = "<div h_zero><div class=\"cnprv\"><p fz_10><b>"+langTxt(601)+"</b></p><p fz_10>"+cnameAdd+"</p></div></div>";
      
            let imgSup = $.inArray(chatFileType,imgExt);
            let otheSup = $.inArray(chatFileType,otherExt);

            var img ='<div chat-state-data="1" name-data="'+cfilename+'" ondblclick="enlargeImg(\'#dvimg'+i+'\')" date-data="'+file.lastModified+'" size-data="'+file.size+'" url-data="" class="chatDoc'+addClass+'" id="dvimg'+i+'">'+del+'<div onclick="expandImage(\'#dvimg'+i+'\',\'chatDoc\', \'chatdoc_active\'); setSizeInfo(\''+file.lastModified+'\',\''+file.size+'\');" style="height: 100px"><div class="iconh">'+(i + 1)+'</div>'+addHtml+'</div></div>';

            $('#docHolder').html($('#docHolder').html()+''+img);
            const reader = new FileReader();
            reader.onload = (e) => {
                if (imgSup >= 0) {
                     var url = reader.result;               
                }else{
                    if(otheSup >= 0){
                     var url = 'assets/images/icon/'+chatFileType+'.png';
                    }else{
                        var url = 'assets/images/icon/txt.png';
                    }
                }
                $("#dvimg"+i).css({"background":"url('"+url+"'", "background-position" : "center", "background-size" : "cover", "background-repeat" : "no-repeat"}); ;
                 $("#dvimg"+i).attr("url-data", url); 
            };

            // Read the file as Data URL
            reader.readAsDataURL(file);
        

            previewDoc();
        }else{
            removeFiles(cfilename);
        }
    };
}

function removeImg(id,i,lastModified,size) {
    $(id).slideUp(200);
    $(id).attr("chat-state-data","0");
    var name = $(id).attr('name-data');

    var next = document.querySelectorAll('[chat-state-data="1"]');
    if(next.length > 0){
        for (var i = 0; i < next.length; i++) {         
            expandImage(next[i], 'chatDoc', 'chatdoc_active');
            setSizeInfo($(next[i]).attr('date-data'),$(next[i]).attr('size-data'));
            break;
        }
        for (var i = 0; i < next.length; i++) { 
            var id = $(next[i]).attr("id");
            $("#"+id+" .iconh").html(i+1);
        }
        removeFiles(name);
    }else{
        $('#p2pdoc').val(''); 
        previewDoc();
    }   
}
function removeFiles(fileToRemove) {
    const inputDoc = document.getElementById('p2pdoc');
    const files = inputDoc.files;
    const dt = new DataTransfer(); // Create a DataTransfer object

    // Loop through the files and add them to the DataTransfer object, except the one to remove
    for (let i = 0; i < files.length; i++) {
      if (files[i].name !== fileToRemove) {
        dt.items.add(files[i]);
      }
    }

    // Assign the updated files to the input element
    inputDoc.files = dt.files;
}
function expandImage(img, dClass, addClass) {
    $("."+dClass).attr('class', dClass); 
    $(img).attr('class', 'chatDoc '+addClass);
}


function  setSizeInfo(d_date,size) {
    $('#chatFileSize').html(formatMemorySize(parseInt(size)));
    $('#chatDateModeified').html(lastSeenTime(timeStamp(), parseInt(d_date)/1000, 600));
}
function sortDivs(attr,container,asc) {
    const mgsDivHolder = document.getElementById(container);
    if(mgsDivHolder !== undefined && mgsDivHolder !== null){
        const divs = Array.from(mgsDivHolder.children);
        

        // Sort the divs based on the 'data-data' attribute
        divs.sort((a, b) => {
            const aData = parseInt(a.getAttribute(attr));
            const bData = parseInt(b.getAttribute(attr));
            if(asc !== undefined){
                return aData - bData;
            }else{
                return bData - aData;
            }
        });

        // Append the sorted divs back into the container
        divs.forEach(div => mgsDivHolder.appendChild(div));
    }
}




function formatMemorySize(bytes) {
    const units = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    let i = 0;
    // Convert bytes to appropriate unit
    while (bytes >= 1024 && i < units.length - 1) {
        bytes /= 1024;
        i++;
    }
    // Return the formatted result with 1 decimal point if needed
    return `${bytes.toFixed(bytes % 1 === 0 ? 0 : 1)} ${units[i]}`;
}
function enlargeImg(id) {
    var ur = $(id).attr('url-data');
    if(ur === undefined){
        ur = $(id).attr('src');
    }
    sharePop('<div center><img src="'+ur+'" w_100 class="dubcl"></div>', true);
}

function previewDoc() {
    $('.chatbtn').hide();
    if($('#p2pdoc').val() ===""){
        $("#textFlo").css({"padding-left" : "48px"});
        $('#docPreviewHolder').slideUp(200);
        $('.plusd').show();
        var txt = $('#chatTextarea').val();
        if(txt === undefined || txt ===""){            
            $('#recordBtn').show();
        }else{
            $('#sendBtn').show();
        }
    }else{
        $("#textFlo").css({"padding-left" : "0px"});
        $('#docPreviewHolder').slideDown(400);
        $('.plusd').hide();
        $('#sendBtn').show();
    }
}


function countVisibleLines(id) {
    $(id).css({"height": "40px"});   
    const textarea = document.querySelector(id);   
    var scrollHeight = textarea.scrollHeight; 
    if(scrollHeight === 43){ scrollHeight = 40; }
    $(id).css({"height": scrollHeight+"px"});
}

function generateQr(id, text) {
    var qrcode = new QRCode(id,text);
}

function smartNumberFormat(number) {
    number = number ? (number).toString().replace(/,/g, '') : 0;
    number = number.toString();
  if (number === '0') {
    return '0.00';
  } else {
    number = number.replace(/,/g, ''); // Remove commas
    let num = Number(number).toFixed(2); // Format to 2 decimal places

    if ((number.split('.')[1] && number.split('.')[1].substring(0, 2) <= 0) || number.indexOf('.') < 0) {
      num = Number(number).toFixed(0); // Format without decimal places
    }
    num = num_format(num, undefined,2);
    if(num === "0" || num === 0){
        num ="0.00";
    }
    return num;
  }
}






function moreTxt(platform) {
    let actionTxt ='<h2 style="color: var(--blue);">'+langTxt(242)+'</h2><ol  class="oli"><li>'+langTxt(244)+'</li><li>'+langTxt(245)+'</li><li>'+langTxt(246)+'</li><li>'+langTxt(247)+'</li><li>'+langTxt(248)+'</li><li>'+langTxt(240)+'</li></ol>';

    let actionTxtAdd ='<br><div><button onclick="sharePop(tvHtml('+platform+'));closePop(1);" w_100 class="btn2" style="padding: 10px;">'+langTxt(918)+'</button><div><br>';


    var txt = actionTxt+''+actionTxtAdd; 

    return txt; 
}

function parseLoadUrl(url) {
    if(url.indexOf('?') < 0){
        // url = url+'?auth001='+auth+"&anti_mutation_privacy="+anti+"&loghash="+loghash+"&uidStr="+uidStr+"&logPadHash="+logPadHash;
    }else{
        // if(url.indexOf('#') < 0){
        //     url = url+'&auth001='+auth+"&anti_mutation_privacy="+anti+"&loghash="+loghash+"&uidStr="+uidStr+"&logPadHash="+logPadHash;
        // }
    }
    return(url);
}




















