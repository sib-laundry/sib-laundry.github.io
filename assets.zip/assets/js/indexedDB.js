let db;
let userDetails;
let D_SERVICE;
const databaseName = 'GrowFame-Database-v1';
const request = indexedDB.open(databaseName);
let USER;

request.onupgradeneeded = function(event) {
    db = event.target.result;
    tableAndCulums();
};

request.onsuccess = function(event) {
    db = event.target.result;
    console.log("Database opened successfully at version "+ db.version);
    // console.log(db.name);
    // console.log(db.version);
    initUserDetails();
    
};

request.onerror = function(event) {
    console.log("Error opening database:", event.target.errorCode);
};

// function reOpenDbConnection(){
// 	if(db !== undefined){
// 		db.close();
// 		const request = indexedDB.open(databaseName);
// 		request.onsuccess = function(event) {
// 		    db = event.target.result;
// 		    console.log("Database re-opened successfully at version "+ db.version);
// 		    initUserDetails();
// 		}
// 		request.onerror = function(event) {
// 		    console.log("Error re-opening database:", event.target.errorCode);
// 		};
	    
// 	}
// }


function tableAndCulums(){
	createTable(['tid', 'uid', 'affilate_code', 'email', 'phone', 'firstname', 'surname', 'gender', 'deposit_balance', 'country', 'currency_code', 'currency_symbol', 'app_notification', 'verified_badge', 'd_date', 'language', 'icon', 'login_data'],'users','email', 'status', 'login_is_valid');


    createTable(['tid', 'uid', 'firstname', 'surname', 'icon', 'verified_badge', 'status', 'd_date', 'total_earned', 'next_payout_eanred', 'ref_by'],'referrals','uid');

    createTable(['tid', 'min_deposit', ],'system_settings');

     createTable(['tid','uid','txn_ref','amount','country','currency_symbol','currency_code','d_date','method','coin','d_value','link','status'],'deposit', 'txn_ref');




    // createTable(['tid', 'uid', 'title', 'message', 'flyer', 'url', 'd_date', 'status', 'type','seen'],'app_notification','tid');

}

const createTable =  async (keys,table,u,) => {
	var stores = await db.objectStoreNames;
	let objectStore;
	var exist = await db.objectStoreNames.contains(table);
	if(!exist){		
		objectStore = db.createObjectStore(table, { keyPath: "id", autoIncrement: true });
		var check = 0;
	}else{
		objectStore =  stores;
		var check = 1;
	}
	var len = keys.length
	for (var i = 0; i < len; i++) {
		var key = keys[i];
		var uniq = false;
		if(u !== undefined){
			if(key  === u){
				uniq = true;
			}
		}
		if(check === 0){			
			objectStore.createIndex(key, key, { unique: uniq });
		}else{
			if(objectStore.indexNames !== undefined){
				var exist = await objectStore.indexNames.contains(key);
				if(!exist){
					objectStore.createIndex(key, key, { unique: uniq });
				}
			}
		}
		
	}
}

function resetDB(){
	if(db !== undefined){
		db.close();
	}
	const newVersion = db.version + 1;  // Increment the version number to trigger onupgradeneeded

	const request = indexedDB.open(databaseName, newVersion);
	request.onupgradeneeded = function(event) {
		db = event.target.result;
		tableAndCulums();
		// db.close();
	}
	request.onsuccess = function(event) {
	  db = event.target.result;
	  // db.close();
	};
}


function addUser(table, user, callBack) {
	if(db!== undefined){		
		if(jsGetAllTableNames().length > 0){
			if(jsGetAllTableNames().contains(table)){
			    const transaction = db.transaction([table], "readwrite");
			    const objectStore = transaction.objectStore(table);
			    const request = objectStore.add(user);

			    request.onsuccess = function() {
			        console.log("User added successfully");
			        if(callBack !== undefined){
			        	callBack();
			    	}
			    };

			    request.onerror = function(event) {
			        console.log("Error adding user: "+table+' ', ':',event.target.error);
			    };
			}else{if(callBack !== undefined){ callBack(); }}
		}else{if(callBack !== undefined){ callBack(); }}
	}else{ if(callBack !== undefined){ callBack(); }}
}

// Add a user
// addUser({ name: "John Doe", email: "john@example.com" });



function getUserById(id,table, callBack) {
    const transaction = db.transaction([table], "readonly");
    const objectStore = transaction.objectStore(table);
    const request = objectStore.get(id);

    request.onsuccess = function(event) {
        const user = event.target.result;
        if (user) {
            console.log("User found:", user);
        } else {
            console.log("User not found");
        }
    };

    request.onerror = function() {
        console.log("Error retrieving user");
    };
}

// Get user by ID (e.g., ID = 1)
// getUserById(1);





function updateUser(colum, table, value, updatedData, callBack) {
	if(db !== undefined){
		if(jsGetAllTableNames().contains(table)){
		    const transaction = db.transaction([table], "readwrite");
		    const objectStore = transaction.objectStore(table);
		    const index = objectStore.index(colum) || false;
		    if(index){
			    const request = index.getAll(value);

			    request.onsuccess = function(event) {
			        const users = event.target.result;

			        if (users) {
			        	users.forEach(user =>{
				            Object.assign(user, updatedData);
				            const updateRequest = objectStore.put(user);

				            updateRequest.onsuccess = function() {
				                console.log("User updated successfully: "+table);
				                if(table === "users"){
				                	initUserDetails();
				                }
				                if(callBack !== undefined){ callBack([414]); }
				            };

				            updateRequest.onerror = function() {
				                console.log("Error updating user");
				                 if(callBack !== undefined){ callBack([381]); }
				            };
				        });
			        } else {
			            console.log("User not found");
			            if(callBack !== undefined){ callBack([381]); }
			        }
			    };

			    request.onerror = function() {
			        console.log("Error retrieving user for update");
			    };
			}else{ if(callBack !== undefined){ callBack([381]); }}
		}else{ if(callBack !== undefined){ callBack([381]); }}
	}else{ if(callBack !== undefined){ callBack([381]); }}
}

// Update user with ID 1
// updateUser(1, { email: "john.new@example.com" });




function deleteUser(id,table) {
	if(db !== undefined){
		if(jsGetAllTableNames().contains(table)){
		    const transaction = db.transaction([table], "readwrite");
		    const objectStore = transaction.objectStore(table);
		    const request = objectStore.delete(id);

		    request.onsuccess = function() {
		        console.log("User deleted successfully");
		    };

		    request.onerror = function() {
		        console.log("Error deleting user");
		    };
		}
	}
}


function jsGetRowData(colum, table, value, callBack) {
	if(db !== undefined){
		if(db.objectStoreNames.contains(table)){
		    const transaction = db.transaction([table], "readonly");		   	
		    const objectStore = transaction.objectStore(table);
		    const index = objectStore.index(colum) || false;
		    if(index){
			    const request = index.getAll(value);
			    request.onsuccess = function(event) {
			        const row = event.target.result;        
			        if (row) {
			            callBack(row);
			        } else {
			            callBack([]);
			        }

			    };
			    request.onerror = function() {
			    	callBack([]);
			        console.log("Error retrieving user by name");
			    };
			}else{ callBack([]); }
		}else{ callBack([]); }
	}else{ callBack([]); }
}


function jsRowData(row){
	console.log('SEEN: ',row);
}

function jsTableData(rows, table){
	console.log(table,':',rows);
}


function jsGetMultiData(table, callBack) {
	if(db !==  undefined){
		if(jsGetAllTableNames().contains(table)){
			const transaction = db.transaction([table], "readonly");
		    const objectStore = transaction.objectStore(table);
		    const request = objectStore.getAll();
		    request.onsuccess = function(event) {
		        const allRecords = event.target.result;
		        if (allRecords) {
		            callBack(allRecords, table);
		        } else {
		            callBack([], table);
		        }
		    };

		    request.onerror = function() {
		    	callBack([], table);
		        // console.log("Error retrieving user by name");

		    };
		}
	}
    
}

// Delete user with ID 1
// deleteUser(1);



function jsGetAllTableNames(){
	if(db !== undefined){
		if(db.objectStoreNames.length > 0){
			return db.objectStoreNames;
		}else{
			return [];
		}
	}else{		
		return [];
	}

}



function deleteTable(table){
	if(db !== undefined){
		if(jsGetAllTableNames().contains(table)){
			db.close();
			const newVersion = db.version + 1;  // Increment the version number to trigger onupgradeneeded
			// console.log(databaseName+" == "+newVersion+" == "+table);

			const request1 = indexedDB.open(databaseName, newVersion);
			

			request1.onupgradeneeded = function(event) {
				console.log(request1);
			  db = event.target.result;
			  if (db.objectStoreNames.contains(table)) {
			    db.deleteObjectStore(table);  // Delete the object store (table)
			    console.log("Object store '"+table+"' deleted successfully.");
			  } else {
			    console.log("Object store '"+table+"' does not exist.");
			  }
			};

			request1.onsuccess = function(event) {
			  db = event.target.result;
			  console.log("Database opened successfully.");

			  // Close the database connection
			  // db.close();
			};

			request1.onerror = function(event) {
			  console.error(`Error opening database ${databaseName}:`, event.target.error);
			};

			request1.onblocked = function(event) {
			  console.warn(`Database deletion blocked. Close other connections to ${databaseName} to delete it.`);
			  db.close();
			};
		}
	}else{
		console.log("Database not connected.");
	}
}










function deleteDB(databaseName){
	if(db !== undefined){
		const deleteRequest = indexedDB.deleteDatabase(databaseName);

		deleteRequest.onsuccess = function(event) {
		  console.log(`Database ${databaseName} deleted successfully.`);
		};

		deleteRequest.onerror = function(event) {
		  console.error(`Error deleting database ${databaseName}:`, event);
		};

		deleteRequest.onblocked = function(event) {
		  console.warn(`Database deletion blocked. Close other connections to ${databaseName} to delete it.`);
		  db.close();
		};
	}
}


function initUserDetails(uid){
	if(uid ===undefined){
		uid = localStorage.getItem('USER_ID');
	}
	if(uid !== undefined){
		jsGetRowData('uid', 'users', uid, (content)=>{
			if(content.length > 0){
				userDetails = content[0];
			}
		});
	}
}


function getUserDetails(index){
	return userDetails;

}



