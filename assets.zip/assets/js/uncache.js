localStorage.setItem('WORKER_VERSION', 7);

if ('serviceWorker' in navigator) {
	if(navigator.serviceWorker.controller !== null){
		navigator.serviceWorker.controller.postMessage([localStorage.getItem('WORKER_VERSION')]);
	}	
}



localStorage.setItem('PAGE_VERSION_register', 1);
localStorage.setItem('PAGE_VERSION_transaction', 1);
localStorage.setItem('PAGE_VERSION_home', 2);
localStorage.setItem('PAGE_VERSION_chat', 2);
localStorage.setItem('PAGE_VERSION_deposit_record', 1);
localStorage.setItem('PAGE_VERSION_deposit', 3);
localStorage.setItem('PAGE_VERSION_p2p_sell', 1);
localStorage.setItem('PAGE_VERSION_text_to_speech', 1);
localStorage.setItem('PAGE_VERSION_p2p', 1);
localStorage.setItem('PAGE_VERSION_bulk_sms_record', 1);
localStorage.setItem('PAGE_VERSION_bulk_sms', 1);
localStorage.setItem('PAGE_VERSION_contact_us', 1);
localStorage.setItem('PAGE_VERSION_print_card', 2);
localStorage.setItem('PAGE_VERSION_buy_data', 4);
localStorage.setItem('PAGE_VERSION_buy_airtime', 4);
localStorage.setItem('PAGE_VERSION_profile', 1);
localStorage.setItem('PAGE_VERSION_login', 3);
localStorage.setItem('PAGE_VERSION_whatsapp_tv', 2);
localStorage.setItem('PAGE_VERSION_telegram_tv', 2);
localStorage.setItem('PAGE_VERSION_get_website', 2);
localStorage.setItem('PAGE_VERSION_pay_bills', 2);
localStorage.setItem('PAGE_VERSION_app_notification', 1);
localStorage.setItem('PAGE_VERSION_pay_bill_record', 1);
localStorage.setItem('PAGE_VERSION_airtime_record', 3);
localStorage.setItem('PAGE_VERSION_buy_data_record', 1);
localStorage.setItem('PAGE_VERSION_offline_data', 3);
localStorage.setItem('PAGE_VERSION_offline_data_beneficiary', 2);



localStorage.setItem('LANG_VERSION', 1);



localStorage.setItem('VERSION_menuHolder', 1);
localStorage.setItem('VERSION_more_services', 1);
localStorage.setItem('VERSION_more_services2', 1);
localStorage.setItem('VERSION_bottomHolder', 1);


localStorage.setItem('VERSION_pop_login', 1);


class LocalUser {
	constructor(data, feedback) {
		this.data = data;
		this.feedback = feedback;
	}

	set(data1) {
		const data2 = [data1];
		const localData = this.data;
		if(this.isNotEmpty(data2)){
			const allKeys = [... new Set(data2.flatMap(Object.keys))];
			for (var i = 0; i < allKeys.length; i++) {
				const key = allKeys[i];
				if(!this.isCoreEmpty(localData[key])){
				 	localStorage.setItem(localData[key],  data1[key]);
				 	if(this.feedback === true){
				 		console.log('localStorage: ['+localData[key]+'] as ['+key+'] set succefully \nValue: '+data1[key]);
				 	}
				}else{
				 	console.error('Unable to set localStorage valud for '+key+'. \n "'+key+'" is not initialized');
				}				 
			}
		}
	}

	get(key) {
		const localData = this.data;
		if(!this.isCoreEmpty(key)){
			if(!this.isCoreEmpty(localData[key])){
				const item = localStorage.getItem(localData[key]);
				if(this.feedback === true){
					console.log('localStorage: ['+localData[key]+'] as ['+key+'] get succefully \nValue: '+item);
				}
			 	return item;
			}else{
			 	console.error('Unable to get localStorage valud for '+key+'. \n "'+key+'" is not initialized');
			}		
		}
		return null;
	}

	isNotEmpty(val) {
	    return val === null || val === undefined || val === "" || isNaN(val);
	}
	isCoreEmpty(strArr){
    if(strArr === undefined || strArr ===null  || strArr === false || strArr === "undefined" || strArr === "" || strArr ==="null"){

       return true;
    }else{
        return false;
    }

}
}

const localUser = new LocalUser({uid: 'GROW_UID', login: 'GROW_LOGIN', ref: 'GROW_REF', page_index: 'GROW_PAGE_INDEX'}, false);

// localUser.set({uid: 1, login: false, auth: 2222});

// console.log(localUser.get('uid'));
