let coData;
let tryWait;

function translateHTML(pageId){
    if(lang !== undefined){
        executeTrans(pageId);
    }
}


function executeTrans(pageId){
    if(pageId !== false){
        if(pageId.indexOf("_page") > 0){
            setNavInfo();
        }
    }
    const curLang = localStorage.getItem('CURRENT_LANGUAGE');
    if(curLang === "english" || curLang === undefined || curLang === null || pageId === false){
        return false;
    }
    if(pageId !== undefined){ pageId = ""; }else{ pageId = pageId.trim()+" "; }
    var content = document.querySelectorAll(pageId+'[data-lang]');
    var len = content.length;
    if(content.length > 0){
        for (var i = 0; i < len; i++) {
            var key = $(content[i]).attr('data-lang');
            $(content[i]).html(lang[key]);                                       
        }
    }

    var content = document.querySelectorAll(pageId+'[data-lang-placeholder]');
    var len = content.length;
    if(content.length > 0){
        for (var i = 0; i < len; i++) {
            var key = $(content[i]).attr('data-lang-placeholder');
            $(content[i]).attr('placeholder', lang[key]);                   
        }
    }

    var content = document.querySelectorAll(pageId+'[data-lang-label]');
    var len = content.length;
    if(content.length > 0){
        for (var i = 0; i < len; i++) {
            var key = $(content[i]).attr('data-lang-label');
            $(content[i]).attr('label', lang[key]);                   
        }
    }
}


function langTxt(t){
    return lang[t] !== undefined ? lang[t] : '';
}

translateHTML(false);

